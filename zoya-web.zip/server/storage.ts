import { db } from "./db";
import {
  waitlist,
  type InsertWaitlist,
  type WaitlistResponse
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  createWaitlistEntry(entry: InsertWaitlist): Promise<WaitlistResponse>;
}

export class DatabaseStorage implements IStorage {
  async createWaitlistEntry(entry: InsertWaitlist): Promise<WaitlistResponse> {
    const [created] = await db.insert(waitlist).values(entry).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
