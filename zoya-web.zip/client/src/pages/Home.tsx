import { useState } from "react";
import { motion } from "framer-motion";
import Typewriter from "typewriter-effect";
import CountUp from "react-countup";
import { useInView } from "react-intersection-observer";
import { Headphones, Zap, ListMusic, Bot, ShieldCheck, Activity, Play, Pause, SkipForward, List, Square, Volume2 } from "lucide-react";

import { LoadingScreen } from "@/components/LoadingScreen";
import { ParticlesBackground } from "@/components/ParticlesBackground";
import { Navigation } from "@/components/Navigation";
import { AudioVisualizer } from "@/components/AudioVisualizer";
import logoImg from "@assets/images_(5)_1772725982431.jpeg";
import { useJoinWaitlist } from "@/hooks/use-waitlist";
import { useToast } from "@/hooks/use-toast";

// Animations
const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15
    }
  }
};

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  const [statsRef, statsInView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const waitlistMutation = useJoinWaitlist();
  const [email, setEmail] = useState("");

  const handleWaitlistSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    waitlistMutation.mutate({ email }, {
      onSuccess: () => {
        toast({
          title: "Subscribed!",
          description: "You'll be notified of Zoya updates.",
        });
        setEmail("");
      },
      onError: (err) => {
        toast({
          variant: "destructive",
          title: "Error",
          description: err.message,
        });
      }
    });
  };

  if (isLoading) {
    return <LoadingScreen onComplete={() => setIsLoading(false)} />;
  }

  return (
    <main className="relative min-h-screen selection:bg-purple-500/30 selection:text-white">
      <ParticlesBackground />
      <Navigation />

      {/* HERO SECTION */}
      <section className="relative pt-40 pb-20 md:pt-52 md:pb-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col items-center justify-center text-center">
        
        <motion.div 
          initial="hidden" animate="visible" variants={fadeInUp}
          className="relative mb-8"
        >
          <div className="absolute inset-0 bg-purple-600/30 blur-[80px] rounded-full pointer-events-none" />
          <img 
            src={logoImg} 
            alt="Zoya Mascot" 
            className="w-40 h-40 md:w-56 md:h-56 rounded-full object-cover border-4 border-white/10 shadow-[0_0_50px_rgba(168,85,247,0.4)] relative z-10"
          />
        </motion.div>

        <motion.h1 
          initial="hidden" animate="visible" variants={fadeInUp} custom={1}
          className="text-6xl md:text-8xl lg:text-9xl font-display font-bold italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white via-purple-100 to-purple-600 mb-4 text-glow"
        >
          ZOYA
        </motion.h1>

        <motion.div 
          initial="hidden" animate="visible" variants={fadeInUp} custom={2}
          className="text-xl md:text-3xl font-medium text-purple-300 mb-6 h-12 flex items-center justify-center"
        >
          <Typewriter
            options={{
              strings: [
                'High quality music streaming',
                'Lightning fast playback',
                'Lag free music experience',
                'Powerful music commands',
                'The perfect Discord music companion'
              ],
              autoStart: true,
              loop: true,
              delay: 50,
              deleteSpeed: 30,
              cursorClassName: "text-pink-500 animate-pulse"
            }}
          />
        </motion.div>

        <motion.p 
          initial="hidden" animate="visible" variants={fadeInUp} custom={3}
          className="max-w-2xl text-base md:text-lg text-white/60 mb-2"
        >
          A powerful Discord music bot designed for smooth, high quality music playback.
        </motion.p>
        
        <motion.p 
          initial="hidden" animate="visible" variants={fadeInUp} custom={4}
          className="text-sm text-purple-400/80 tracking-widest uppercase mb-12"
        >
          Developed by <span className="text-white font-semibold">Rex</span> & <span className="text-white font-semibold">Samir</span>
        </motion.p>

        <motion.div 
          initial="hidden" animate="visible" variants={fadeInUp} custom={5}
          className="flex flex-col sm:flex-row gap-6 w-full sm:w-auto"
        >
          <a 
            href="https://discord.com/oauth2/authorize?client_id=1461587090897633469&permissions=8&integration_type=0&scope=bot+applications.commands"
            target="_blank" rel="noopener noreferrer"
            className="group relative px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl font-bold text-white text-lg overflow-hidden transition-all hover:scale-105 box-glow"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
            <span className="relative z-10 flex items-center justify-center gap-2">
              <Bot className="w-5 h-5" /> Invite Zoya
            </span>
          </a>
          
          <a 
            href="https://discord.gg/2MvqmvXrvH"
            target="_blank" rel="noopener noreferrer"
            className="group relative px-8 py-4 bg-white/5 border border-purple-500/30 rounded-2xl font-bold text-purple-200 text-lg overflow-hidden transition-all hover:bg-white/10 hover:border-purple-400 hover:scale-105 backdrop-blur-md"
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              Support Server
            </span>
          </a>
        </motion.div>
      </section>

      {/* VISUAL SHOWCASE */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-900/10 to-transparent pointer-events-none" />
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1 }}
          className="relative z-10"
        >
          <AudioVisualizer />
        </motion.div>
      </section>

      {/* FEATURES SECTION */}
      <section id="features" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">Unmatched <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">Performance</span></h2>
          <p className="text-white/60 max-w-2xl mx-auto">Experience music in your server like never before with our carefully engineered architecture.</p>
        </div>

        <motion.div 
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {[
            { icon: Headphones, title: "High Quality Audio", desc: "Crystal clear audio playback using the latest encoding technologies." },
            { icon: Zap, title: "Fast & Responsive", desc: "Instant command execution with zero latency or lag." },
            { icon: ListMusic, title: "Advanced Queue", desc: "Manage your server's playlist with an intuitive and powerful queue system." },
            { icon: Bot, title: "Seamless Integration", desc: "Native Discord UI support with buttons and sleek embed menus." },
            { icon: ShieldCheck, title: "Stable Uptime", desc: "99.9% uptime guaranteed, so the music never stops playing." },
            { icon: Activity, title: "Smooth Streaming", desc: "Optimized buffer handling for stutter-free listening sessions." }
          ].map((feature, i) => (
            <motion.div 
              key={i} variants={fadeInUp}
              className="glass-panel glass-panel-hover p-8 rounded-3xl group"
            >
              <div className="w-14 h-14 rounded-2xl bg-purple-500/20 flex items-center justify-center mb-6 group-hover:bg-purple-500/40 transition-colors border border-purple-500/30">
                <feature.icon className="w-7 h-7 text-purple-300" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-white/60 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* COMMANDS SECTION */}
      <section id="commands" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[500px] bg-pink-600/10 blur-[120px] rounded-full pointer-events-none" />
        
        <div className="text-center mb-16 relative z-10">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">Sleek <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-500">Commands</span></h2>
          <p className="text-white/60 max-w-2xl mx-auto">Everything you need to control the vibe, right at your fingertips.</p>
        </div>

        <motion.div 
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 relative z-10"
        >
          {[
            { cmd: "/play", icon: Play, desc: "Start the music" },
            { cmd: "/pause", icon: Pause, desc: "Hold the track" },
            { cmd: "/skip", icon: SkipForward, desc: "Next song" },
            { cmd: "/queue", icon: List, desc: "View upcoming" },
            { cmd: "/stop", icon: Square, desc: "Clear & leave" },
            { cmd: "/volume", icon: Volume2, desc: "Adjust levels" }
          ].map((cmd, i) => (
            <motion.div 
              key={i} variants={fadeInUp}
              className="glass-panel p-6 rounded-2xl flex flex-col items-center justify-center text-center hover:-translate-y-2 hover:bg-white/10 hover:border-pink-500/30 transition-all duration-300 cursor-default box-glow-hover group"
            >
              <cmd.icon className="w-8 h-8 text-pink-400 mb-3 group-hover:scale-110 transition-transform" />
              <div className="font-mono text-lg font-bold text-white mb-1">{cmd.cmd}</div>
              <div className="text-xs text-white/50">{cmd.desc}</div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* STATISTICS SECTION */}
      <section id="stats" className="py-20 border-y border-white/5 bg-black/40 backdrop-blur-sm mt-12" ref={statsRef}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 text-center">
            {[
              { label: "Servers", value: 1540, suffix: "+" },
              { label: "Songs Played", value: 520, suffix: "K+" },
              { label: "Commands", value: 2.1, suffix: "M" },
              { label: "Active Users", value: 145, suffix: "K" }
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center justify-center">
                <div className="text-4xl md:text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-purple-400 mb-2">
                  {statsInView ? (
                    <CountUp end={stat.value} duration={2.5} decimals={stat.value % 1 !== 0 ? 1 : 0} />
                  ) : "0"}
                  {stat.suffix}
                </div>
                <div className="text-sm md:text-base text-purple-200/60 uppercase tracking-widest font-semibold">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DEVELOPERS SECTION */}
      <section id="developers" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">The <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">Minds</span> Behind Zoya</h2>
        </div>

        <div className="flex flex-col md:flex-row justify-center items-center gap-8 lg:gap-16">
          {[
            { name: "Rex", role: "Lead Developer", glow: "rgba(168,85,247,0.5)" },
            { name: "Samir", role: "Systems Architect", glow: "rgba(236,72,153,0.5)" }
          ].map((dev, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.2 }}
              className="relative w-full max-w-sm group"
            >
              <div 
                className="absolute inset-0 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl"
                style={{ backgroundColor: dev.glow }}
              />
              <div className="relative glass-panel rounded-3xl p-8 flex flex-col items-center text-center border border-white/10 group-hover:border-white/20 overflow-hidden">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-gray-800 to-black border-2 border-white/20 mb-6 flex items-center justify-center text-3xl font-display text-white/50">
                  {dev.name[0]}
                </div>
                <h3 className="text-2xl font-bold text-white mb-1">{dev.name}</h3>
                <p className="text-purple-300/80 text-sm tracking-widest uppercase mb-4">{dev.role}</p>
                <div className="w-8 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer className="pt-20 pb-10 px-4 border-t border-white/5 bg-black/60 relative z-10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8 mb-12">
          <div className="flex items-center gap-4">
            <img src={logoImg} alt="Zoya" className="w-12 h-12 rounded-full border border-purple-500/30" />
            <div>
              <h2 className="text-2xl font-display font-bold text-white tracking-wider">ZOYA</h2>
              <p className="text-white/40 text-sm">Premium Discord Audio</p>
            </div>
          </div>

          <div className="flex gap-4">
            <a href="https://discord.gg/2MvqmvXrvH" target="_blank" rel="noopener noreferrer" className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 transition-colors border border-white/10 text-sm font-semibold">
              Support Server
            </a>
            <a href="https://discord.com/oauth2/authorize?client_id=1461587090897633469&permissions=8&integration_type=0&scope=bot+applications.commands" target="_blank" rel="noopener noreferrer" className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-colors text-sm font-semibold box-glow">
              Invite Bot
            </a>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/40">
          <p>© {new Date().getFullYear()} Zoya Bot. All rights reserved.</p>
          <p>Developed with 💜 by Rex & Samir</p>
        </div>
      </footer>
    </main>
  );
}
