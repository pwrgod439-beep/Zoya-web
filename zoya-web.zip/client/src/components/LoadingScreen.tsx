import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import logoImg from "@assets/images_(5)_1772725982431.jpeg";

export function LoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsExiting(true);
      setTimeout(onComplete, 800); // Wait for fade out animation
    }, 2000); // Display loading for 2 seconds

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: isExiting ? 0 : 1 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#05010d]"
    >
      <div className="relative">
        {/* Glow effect behind logo */}
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.5, 0.8, 0.5] 
          }}
          transition={{ 
            duration: 1.5, 
            repeat: Infinity,
            ease: "easeInOut" 
          }}
          className="absolute inset-0 bg-purple-600 blur-[40px] rounded-full"
        />
        
        <img 
          src={logoImg} 
          alt="Zoya Loading" 
          className="relative z-10 w-32 h-32 rounded-full border-2 border-purple-500/50 object-cover box-glow"
        />
      </div>
      
      <motion.h1 
        animate={{ opacity: [0.4, 1, 0.4] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        className="mt-8 text-2xl font-display font-bold tracking-[0.2em] text-white text-glow"
      >
        INITIALIZING ZOYA
      </motion.h1>
      
      <div className="mt-6 w-48 h-1 bg-white/10 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: "0%" }}
          animate={{ width: "100%" }}
          transition={{ duration: 1.8, ease: "easeInOut" }}
          className="h-full bg-gradient-to-r from-purple-600 to-pink-500 rounded-full box-glow"
        />
      </div>
    </motion.div>
  );
}
