import { motion } from "framer-motion";
import logoImg from "@assets/images_(5)_1772725982431.jpeg";

export function Navigation() {
  return (
    <motion.nav 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 py-4 px-6 md:px-12 flex items-center justify-between glass-panel border-x-0 border-t-0 rounded-none"
    >
      <div className="flex items-center gap-4">
        <img src={logoImg} alt="Zoya Logo" className="w-10 h-10 rounded-full object-cover shadow-[0_0_10px_rgba(168,85,247,0.5)]" />
        <span className="text-xl font-display font-bold tracking-wider text-white text-glow">ZOYA</span>
      </div>
      
      <div className="hidden md:flex items-center gap-8 text-sm font-medium text-white/70">
        <a href="#features" className="hover:text-purple-400 transition-colors">Features</a>
        <a href="#commands" className="hover:text-purple-400 transition-colors">Commands</a>
        <a href="#stats" className="hover:text-purple-400 transition-colors">Statistics</a>
        <a href="#developers" className="hover:text-purple-400 transition-colors">Team</a>
      </div>
      
      <a 
        href="https://discord.com/oauth2/authorize?client_id=1461587090897633469&permissions=8&integration_type=0&scope=bot+applications.commands"
        target="_blank"
        rel="noopener noreferrer"
        className="px-6 py-2 rounded-full bg-purple-600/20 border border-purple-500/50 text-purple-100 font-semibold text-sm hover:bg-purple-600/40 hover:border-purple-400 transition-all duration-300 box-glow-hover"
      >
        Add to Discord
      </a>
    </motion.nav>
  );
}
