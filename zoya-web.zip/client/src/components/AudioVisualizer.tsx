import { motion } from "framer-motion";

export function AudioVisualizer() {
  // Generate 20 bars
  const bars = Array.from({ length: 20 });

  return (
    <div className="flex items-end justify-center gap-1 sm:gap-2 h-48 w-full max-w-2xl mx-auto opacity-80">
      {bars.map((_, i) => {
        // Randomize animation delays and durations for a realistic wave effect
        const delay = Math.random() * -2;
        const duration = 0.8 + Math.random() * 0.7;
        
        return (
          <motion.div
            key={i}
            className="w-2 sm:w-4 bg-gradient-to-t from-purple-800 via-purple-500 to-pink-400 rounded-t-full box-glow"
            animate={{
              height: ["10%", "100%", "10%"],
            }}
            transition={{
              duration: duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: delay,
            }}
          />
        );
      })}
    </div>
  );
}
