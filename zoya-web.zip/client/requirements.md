## Packages
framer-motion | Core library for smooth, premium scroll and hover animations
typewriter-effect | For the auto-typing effect in the hero section
react-countup | For the animated statistics counters
react-intersection-observer | To trigger counter animations when scrolled into view
react-tsparticles | For the falling star/space particle background
@tsparticles/slim | Lightweight engine for react-tsparticles

## Notes
- Using framer-motion heavily for the "super advanced, premium" feel.
- Using @assets/images_(5)_1772725982431.jpeg for the bot logo.
- Particles background is rendered behind all content with a z-index of -1.
